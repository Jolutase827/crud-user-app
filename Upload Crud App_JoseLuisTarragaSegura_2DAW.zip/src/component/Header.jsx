import React from 'react'

function Header() {
  
    return (
        <header className=''>
            <h1 className='font-sans text-[40px] ms-10 mt-10 font-medium'>Gestión Usuario con Hook</h1>
        </header>
    )
  
}

export default Header